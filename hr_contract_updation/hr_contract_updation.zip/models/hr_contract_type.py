# -*- coding: utf-8 -*-
from odoo import api, fields, models, _

class HrContractType(models.Model):
    _name = 'hr.contract.type'
    _description = 'Loại hợp đồng'

    name = fields.Char(string='Tên loại hợp đồng', required=True)
    code = fields.Selection(
        [('HĐLD', 'HĐ Lao động'), ('HĐTV', 'HĐ Thử việc')],
        string='Mã loại HĐ', required=True, help='Chỉ HĐLD hoặc HĐTV'
    )
    description = fields.Text(string='Ghi chú')
    active = fields.Boolean(string='Hiệu lực', default=True)

    _sql_constraints = [
        ('unique_code', 'unique(code)', 'Mã loại hợp đồng đã tồn tại!'),
    ]

    def name_get(self):
        result = []
        for rec in self:
            name = "[%s] %s" % (rec.code, rec.name or '')
            result.append((rec.id, name))
        return result
