
# -*- coding: utf-8 -*-
from datetime import date, timedelta
from odoo import models, fields, api

class HrContract(models.Model):
    _inherit = 'hr.contract'

    # Tham chiếu loại hợp đồng & mã hợp đồng
    contract_type_id = fields.Many2one('hr.contract.type', string="Loại hợp đồng")
    contract_code = fields.Char(string="Mã hợp đồng", readonly=True, copy=False,
                                help="Công thức: [Mã NV]/[Năm]/[Mã loại HĐ]")

    # Thông tin nhân viên hiển thị trong hợp đồng
    id_number = fields.Char(string="Số CCCD", related='employee_id.identification_id', store=True)
    id_issue_date = fields.Date(string="Ngày cấp CCCD", related='employee_id.id_issue_date', store=True)
    id_issue_place = fields.Char(string="Nơi cấp CCCD", related='employee_id.id_issue_place', store=True)
    permanent_address = fields.Char(string="Thường trú", related='employee_id.private_city', store=True)
    job_title = fields.Char(string="Chức danh", related='employee_id.job_title', store=True)

    @api.onchange('employee_id', 'contract_type_id')
    def _onchange_generate_contract_code(self):
        """Sinh mã hợp đồng: [MãNV]/[Năm]/[MãHĐ]"""
        for rec in self:
            if rec.employee_id and rec.contract_type_id:
                emp_code = rec.employee_id.employee_code or rec.employee_id.identification_id or "NV"
                year_now = str(date.today().year)
                suffix = rec.contract_type_id.code or "HD"
                rec.contract_code = f"{emp_code}/{year_now}/{suffix}"

    @api.model_create_multi
    def create(self, vals_list):
        records = super().create(vals_list)
        for rec in records:
            if not rec.contract_code and rec.employee_id and rec.contract_type_id:
                emp_code = rec.employee_id.employee_code or rec.employee_id.identification_id or "NV"
                year_now = str(date.today().year)
                suffix = rec.contract_type_id.code or "HD"
                rec.contract_code = f"{emp_code}/{year_now}/{suffix}"
        return records

    @api.model
    def _cron_notify_contract_expiration(self):
        """Gửi email cảnh báo hợp đồng sắp hết hạn (15 ngày trước)."""
        today = fields.Date.today()
        warning_date = today + timedelta(days=15)
        contracts = self.search([
            ('date_end', '!=', False),
            ('date_end', '<=', warning_date),
            ('date_end', '>=', today),
            ('state', 'in', ['open', 'pending'])
        ])
        if not contracts:
            return
        template = self.env.ref('hr_contract_updation_vi.mail_template_contract_expire', raise_if_not_found=False)
        hr_managers = self.env.ref('hr.group_hr_manager').users
        for contract in contracts:
            for manager in hr_managers:
                if template:
                    template.sudo().send_mail(contract.id, force_send=True, email_values={'email_to': manager.email or ''})
