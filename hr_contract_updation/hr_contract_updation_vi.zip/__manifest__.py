# -*- coding: utf-8 -*-
{
    'name': 'Cập nhật Hợp đồng Nhân sự (VN)',
    'version': '1.0.0',
    'summary': 'Sinh mã hợp đồng, loại hợp đồng, hiển thị CCCD & địa chỉ, cảnh báo hết hạn',
    'description': """
Module mở rộng Hợp đồng (Odoo 18 Community)
- Tự sinh mã hợp đồng: [Mã NV]/[Năm]/[Mã loại HĐ]
- Quản lý "Loại hợp đồng"
- Hiển thị: Số CCCD, Ngày cấp, Nơi cấp, Thường trú (city), Chức danh
- Cron thông báo hợp đồng sắp hết hạn (15 ngày trước)
    """,
    'author': 'Bạn & ChatGPT',
    'website': 'https://odoo.com',
    'category': 'Nhân sự',
    'depends': ['hr_contract', 'hr', 'mail'],
    'data': [
        'data/hr_contract_type_data.xml',
        'data/contract_expiration_cron.xml',
        'views/hr_contract_type_views.xml',
        'views/hr_contract_views.xml',
    ],
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}
