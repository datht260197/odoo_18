
# -*- coding: utf-8 -*-
from odoo import fields, models

class HrContractType(models.Model):
    _name = 'hr.contract.type'
    _description = 'Loại hợp đồng'

    name = fields.Char(string='Tên loại hợp đồng', required=True)
    code = fields.Char(string='Mã loại HĐ', required=True, help="Ví dụ: HĐLĐ-VHC, HĐTV-VHC, HĐCTV")
    description = fields.Text(string='Ghi chú')
    active = fields.Boolean(string='Hiệu lực', default=True)

    _sql_constraints = [
        ('unique_code', 'unique(code)', 'Mã loại hợp đồng đã tồn tại, vui lòng chọn mã khác!')
    ]

    def name_get(self):
        return [(rec.id, f"[{rec.code}] {rec.name}") for rec in self]
